// SPDX-License-Identifier: BSD-3-Clause
// Copyright Contributors to the OpenEXR Project.

float divide (float x, float y);
float root (float x);
float grow (float x, int y);

