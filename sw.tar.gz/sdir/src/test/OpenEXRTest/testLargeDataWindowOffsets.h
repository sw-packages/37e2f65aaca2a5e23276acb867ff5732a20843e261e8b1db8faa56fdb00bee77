//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Weta Digital, Ltd and Contributors to the OpenEXR Project.
//

#ifndef _TEST_LARGE_DATA_WINDOW_OFFSETS_
#define _TEST_LARGE_DATA_WINDOW_OFFSETS_

void testLargeDataWindowOffsets (const std::string& tempDir);

#endif
